﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirst
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BlogDbContext db = new BlogDbContext();

            //Insertion of data
            //Post post1 = new Post() {
            //    Id = 2,
            //    DatePublished = DateTime.Now,
            //    Title = "Test2",
            //    Body = "Test on Wednesday",
            //};
            //db.Posts.Add(post1);
            //db.SaveChanges();

            //selection of the table from database
            //List<Post> data = db.Posts.ToList();
            //foreach (Post post in data)
            //{
            //    Console.WriteLine(post.Title);
            //}


            //update data fo the table from database
            //var data = db.Posts.FirstOrDefault(p => p.Id == 1);
            //if (data != null)
            //{
            //    data.Title = "Test1";
            //    db.SaveChanges();
            //}

            //remove data fo the table from database
            var data = db.Posts.FirstOrDefault(p => p.Id == 1);
            if (data != null)
            {
                db.Posts.Remove(data);
                db.SaveChanges();
            }




        }
    }
}
